"""Register independently recorded tilted validation against a frozen profile."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import numpy as np

root = Path('/home/alex/betaflight')
base = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('capture')
p.add_argument('--slot')
a = p.parse_args()
folder = base / a.capture
plan_path = base / 'tilted-validation-plan.json'
plan = json.loads(plan_path.read_text())
slot = next(v for v in plan['poses'] if v['id'] == (a.slot or a.capture))
analysis = json.loads((folder / 'analysis.json').read_text())
assert analysis['static_capture_gates_pass'], 'Raw capture failed original static gates; retain and repeat'
profile = base / 'calibration-profile-v1.json'
profile_hash = sha(profile)
assert plan.get('profile_sha256', profile_hash) == profile_hash, 'Frozen profile changed'
plan['profile_sha256'] = profile_hash
validation_path = folder / 'calibration-validation.json'
if not validation_path.exists():
    result = subprocess.run([sys.executable, str(root / 'tools/tricopter/adxl345_logger/calibrate.py'),
        'validate', str(profile), str(folder), '--output', str(validation_path)])
    assert result.returncode in (0, 2), 'Validation input/integrity failure'
validation = json.loads(validation_path.read_text())
assert validation['profile_sha256'] == profile_hash
vector = validation['metrics']['corrected_mean_g']
axes = {'x': 0, 'y': 1, 'z': 2}
coverage = all(sign * vector[axes[axis]] >= .35 for axis, sign in slot['upward_components'].items())
coverage = coverage and abs(vector[axes[slot['near_horizontal_axis']]]) <= .35
passed = bool(validation['norm_screen']['pass'] and coverage)
summary = json.loads((folder / 'summary.json').read_text())
pose = {
    'pose_id': a.capture, 'role': 'independent tilted validation; excluded from fitting',
    'user_description': 'User confirmed named diagonal orientation steady before capture; approximate alignment only.',
    'expected_orientation': {k: slot[k] for k in ['upward_components', 'near_horizontal_axis']},
    'accepted_for_calibration': False, 'accepted_for_validation': passed,
    'calibration_cohort': 'final-wiring-static-fifo', 'profile_sha256': profile_hash,
    'samples': analysis['samples'], 'mean_raw_counts': analysis['mean_raw_counts'],
    'std_raw_counts': analysis['std_raw_counts'], 'static_capture_gates': analysis['gates'],
    'corrected_mean_g': vector, 'corrected_mean_norm_g': validation['metrics']['corrected_mean_norm_g'],
    'norm_residual_g': validation['metrics']['norm_residual_g'],
    'coverage_screen_pass': bool(coverage), 'norm_screen_pass': validation['norm_screen']['pass'],
    'screening_basis': plan['screening_criteria'], 'physical_angle_accuracy_qualified': False,
    'first_capture_utc': summary['started_utc'],
    'file_sha256': {n: sha(folder / n) for n in ['capture.bin', 'records.csv', 'summary.json', 'analysis.json', 'calibration-validation.json']},
}
pose_path = folder / 'pose.json'
assert not pose_path.exists(), 'Pose metadata already exists; do not silently overwrite'
pose_path.write_text(json.dumps(pose, indent=2) + '\n')
slot.setdefault('attempts', []).append(a.capture)
slot['status'] = 'passed' if passed else 'failed screen; repeat/review required'
if passed:
    slot['selected_capture'] = a.capture
slot['corrected_mean_norm_g'] = pose['corrected_mean_norm_g']
plan_path.write_text(json.dumps(plan, indent=2) + '\n')
session_path = base / 'session.json'
session = json.loads(session_path.read_text())
ref = a.capture + '/pose.json'
if ref not in session.setdefault('tilted_validation_pose_manifest', []):
    session['tilted_validation_pose_manifest'].append(ref)
session['tilted_validation_pose_sha256'] = {n: sha(base / n) for n in session['tilted_validation_pose_manifest']}
session['calibration_profile'] = 'calibration-profile-v1.json'
session['calibration_profile_sha256'] = profile_hash
session['calibration_fitted_offline'] = True
session['calibration_applied_to_device'] = False
completed = [v for v in plan['poses'] if v['status'] == 'passed']
session['status'] = f'Bias/diagonal-scale fit frozen; {len(completed)}/6 independent tilted poses passed; no device writes or absolute angle qualification'
session['next_requested_pose'] = next((v['id'] for v in plan['poses'] if v['status'] != 'passed'), 'Mount ADXL on basket and confirm current hardware setup before actuator movement')
session_path.write_text(json.dumps(session, indent=2) + '\n')
captures = []
for entry in completed:
    name = entry['selected_capture']
    meta = json.loads((base / name / 'pose.json').read_text())
    captures.append({'pose_id': name, 'capture_sha256': meta['file_sha256']['capture.bin'],
        'pose_sha256': sha(base / name / 'pose.json'), 'validation_pass': True,
        'corrected_mean_g': meta['corrected_mean_g'], 'norm_residual_g': meta['norm_residual_g']})
aggregate = {
    'schema_version': 1, 'profile': str(profile), 'profile_sha256': profile_hash,
    'independent_static_validation_pass': len(completed) == 6,
    'required_tilted_poses': 6, 'captures': captures,
    'screening_criteria': plan['screening_criteria'],
    'maximum_absolute_tilt_norm_residual_g': max((abs(c['norm_residual_g']) for c in captures), default=None),
    'reference_repeat_norms_g': {r['pose']: r['corrected_mean_norm_g'] for r in json.loads(profile.read_text())['validation']['reference_pose_metrics']},
    'physical_angle_accuracy_qualified': False,
    'interpretation': 'Practical static sensor consistency screening only. Reference drift remains visible; no refitting of held-out poses, device offsets, FC position source or flight-control outputs.'
}
(base / 'tilted-validation-summary.json').write_text(json.dumps(aggregate, indent=2) + '\n')
print(json.dumps({'capture': a.capture, 'passed': passed, 'corrected_mean_g': vector,
    'corrected_mean_norm_g': pose['corrected_mean_norm_g'], 'completed': len(completed),
    'next': session['next_requested_pose']}, indent=2))
raise SystemExit(0 if passed else 2)
