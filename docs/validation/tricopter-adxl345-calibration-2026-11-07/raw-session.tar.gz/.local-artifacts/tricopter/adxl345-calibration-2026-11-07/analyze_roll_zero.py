#!/usr/bin/env python3
"""Project settled gravity into the previously measured hinge plane.

This is an offline experiment analysis, not a flight-control calibration writer.
Zero depends on the operator's X-up-at-flat mounting and roll-level reference.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def basis(normal):
    n = np.asarray(normal, dtype=float)
    n /= np.linalg.norm(n)
    x = np.array([1., 0., 0.]) - n * n[0]
    if np.linalg.norm(x) < .25:
        raise ValueError("Sensor X cannot define zero near the hinge axis")
    x /= np.linalg.norm(x)
    return n, x, np.cross(n, x)


def roll(gravity, normal):
    n, x, y = basis(normal)
    g = np.asarray(gravity, dtype=float)
    gp = g - n * np.dot(g, n)
    if np.linalg.norm(gp) < .25:
        raise ValueError("Insufficient gravity perpendicular to hinge")
    return float(-np.degrees(np.arctan2(np.dot(gp, y), np.dot(gp, x))))


def crossings(points):
    exact = [p for p in points if abs(p['basket_roll_deg']) <= 1e-10]
    if exact:
        if len(exact) != 1:
            raise ValueError('Multiple measured zero points require a zero-band interpretation')
        p = exact[0]
        return {'bracket_plateau_ids': [p['plateau_id'], p['plateau_id']],
                'bracket_command_us': [p['command_us'], p['command_us']],
                'bracket_roll_deg': [p['basket_roll_deg'], p['basket_roll_deg']],
                'interpolated_command_us': p['command_us'],
                'interpolated_pb0_minus_pc0_counts': p['corrected_pb0_minus_pc0_counts'],
                'method': 'direct measured zero; exact shared endpoint counted once'}
    found = []
    for a, b in zip(points, points[1:]):
        if a['basket_roll_deg'] * b['basket_roll_deg'] > 0:
            continue
        delta = b['basket_roll_deg'] - a['basket_roll_deg']
        if abs(delta) < 1e-9 or abs(delta) > 10:
            raise ValueError("Degenerate or excessively wide zero bracket")
        t = -a['basket_roll_deg'] / delta
        found.append({'bracket_plateau_ids': [a['plateau_id'], b['plateau_id']],
                      'bracket_command_us': [a['command_us'], b['command_us']],
                      'bracket_roll_deg': [a['basket_roll_deg'], b['basket_roll_deg']],
                      'interpolated_command_us': a['command_us'] + t * (b['command_us'] - a['command_us']),
                      'interpolated_pb0_minus_pc0_counts': a['corrected_pb0_minus_pc0_counts'] + t * (b['corrected_pb0_minus_pc0_counts'] - a['corrected_pb0_minus_pc0_counts']),
                      'method': 'linear interpolation between adjacent same-approach settled observations; no extrapolation'})
    if len(found) != 1:
        raise ValueError(f"Expected one zero crossing, got {len(found)}")
    return found[0]


def points_from_analysis(analysis, normal):
    return [{'plateau_id': p['plateau_id'], 'command_us': p['target_us'],
             'approach': p['approach'],
             'corrected_pb0_minus_pc0_counts': p['fc']['corrected_pb0_minus_pc0_counts']['mean'],
             'basket_roll_deg': roll(p['adxl']['corrected_mean_g'], normal),
             'hinge_parallel_gravity_g': float(np.dot(p['adxl']['corrected_mean_g'], normal)),
             'settled_window_pass': p['adxl']['settled_mean_screen_pass'] and p['adxl']['paired_observation_qualified']}
            for p in analysis['plateaus']]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('run', type=Path)
    parser.add_argument('--hinge-analysis', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    hinge = json.loads(args.hinge_analysis.read_text())
    analysis = json.loads((args.run / 'analysis.json').read_text())
    if not hinge['rotation_plane']['identified'] or not analysis['all_settled_windows_pass']:
        raise ValueError('Require an identified broad-sweep hinge and passing current settled windows')
    normal = hinge['rotation_plane']['normal_sensor_axes']
    points = points_from_analysis(analysis, normal)
    branches = {}
    for approach in ('increasing', 'decreasing'):
        branch = [p for p in points if p['approach'] == approach]
        # The narrow zero check has one reversal. Full-sweep decreasing passes
        # are not contiguous across the intervening increasing segment.
        branches[approach + '_pwm'] = crossings(branch)
    n, x, y = basis(normal)
    parallel = np.array([p['hinge_parallel_gravity_g'] for p in points])
    initial, final = points[0], points[-1]
    result = {
        'schema_version': 1, 'created_utc': datetime.now(timezone.utc).isoformat(),
        'zero_definition': 'Basket flat in airframe roll plane; operator-aligned PCB +X is up, frame level in roll; motor absent and ADXL mounted in its place',
        'operator_alignment_reference': True,
        'external_motor_shaft_vertical_verified': False,
        'absolute_angle_accuracy_independently_proven': False,
        'position_source': 'fresh signed PB0-PC0 only',
        'sign_convention': 'Mechanical basket rotation about fitted +normal = negative gravity-vector phase; airframe yaw/lean sign unassigned',
        'projection': {'normal_sensor_axes': n.tolist(), 'projected_positive_x': x.tolist(), 'in_plane_quadrature': y.tolist(),
                       'formula': '-atan2(dot(g,cross(n,projected_X)),dot(g,projected_X)) in degrees; reject small perpendicular gravity',
                       'hinge_parallel_component_excluded_from_roll': True},
        'branches': branches, 'points': points,
        'initial_final_same_command_roll_difference_deg': final['basket_roll_deg'] - initial['basket_roll_deg'],
        'mean_hinge_parallel_gravity_g': float(parallel.mean()),
        'apparent_hinge_inclination_deg': float(np.degrees(np.arcsin(np.clip(parallel.mean() / np.mean([p['adxl']['corrected_mean_norm_g'] for p in analysis['plateaus']]), -1, 1)))),
        'inclination_limitation': 'Diagnostic apparent hinge tilt only; sensor mounting, cross-axis error and Z baseline drift limit interpretation as airframe pitch',
        'configuration_restored_exact': analysis['provenance']['servo_restored_exact'],
        'flight_control_calibration_installed': False,
        'provenance': {'analysis_sha256': digest(args.run / 'analysis.json'), 'hinge_analysis_sha256': digest(args.hinge_analysis),
                       'analysis_script_sha256': digest(__file__), 'mounting_reference': 'Latest operator clarification in this chat'}}
    with args.output.open('x') as handle:
        json.dump(result, handle, indent=2, allow_nan=False)
        handle.write('\n')
    print(json.dumps({'branches': branches, 'return_delta_deg': result['initial_final_same_command_roll_difference_deg'],
                      'apparent_hinge_inclination_deg': result['apparent_hinge_inclination_deg']}, indent=2))


if __name__ == '__main__':
    main()
