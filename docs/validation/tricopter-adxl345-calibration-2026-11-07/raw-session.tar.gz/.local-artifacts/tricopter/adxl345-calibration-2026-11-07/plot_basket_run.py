"""Plot measured settled basket data; retain the declared hinge/zero conventions."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=argparse.ArgumentParser(description=__doc__);p.add_argument('folder',type=Path);a=p.parse_args();folder=a.folder
report=json.loads((folder/'analysis.json').read_text());rows=report['plateaus'];identified=report['rotation_plane']['identified']
key='rotation_plane_relative_deg' if identified else 'xy_diagnostic_relative_deg';sign=-1 if identified else 1
angle=lambda r:sign*r[key] if r[key] is not None else np.nan
fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
colors={'increasing':'tab:blue','decreasing':'tab:orange','initial':'black'}
for direction,color in colors.items():
 group=sorted([r for r in rows if r['approach']==direction],key=lambda r:r['target_us'])
 if not group:continue
 label='Initial reference' if direction=='initial' else 'PWM '+direction
 marker='D' if direction=='initial' else 'o'
 ax[0,0].plot([r['target_us'] for r in group],[angle(r) for r in group],marker=marker,ms=3,lw=.8,color=color,label=label)
 ordered=sorted(group,key=lambda r:r['fc']['corrected_pb0_minus_pc0_counts']['mean'])
 ax[0,1].plot([r['fc']['corrected_pb0_minus_pc0_counts']['mean'] for r in ordered],[angle(r) for r in ordered],marker=marker,ms=3,lw=.8,color=color,label=label)
 ax[1,1].plot([r['target_us'] for r in group],[r['adxl']['corrected_mean_norm_g'] for r in group],marker=marker,ms=3,lw=.8,color=color)
angle_label='Relative basket rotation about fitted axis (deg)' if identified else 'Relative XY gravity diagnostic (deg)'
ax[0,0].set_xlabel('Final servo PWM (µs)');ax[0,0].set_ylabel(angle_label);ax[0,0].legend(fontsize=8)
ax[0,1].set_xlabel('Measured PB0−PC0 (ADC counts)');ax[0,1].set_ylabel(angle_label)
comparisons=[r for r in report['same_target_comparisons'] if r['opposite_approaches']]
delta_key='delta_rotation_plane_deg_b_minus_a' if identified else 'delta_xy_diagnostic_deg_b_minus_a'
valid=[r for r in comparisons if r[delta_key] is not None]
ax[1,0].scatter([r['target_us'] for r in valid],[abs(r[delta_key]) for r in valid],s=14)
ax[1,0].set_xlabel('Repeated PWM (µs)');ax[1,0].set_ylabel('Opposite-approach return difference (deg)');ax[1,0].set_ylim(bottom=0)
ax[1,1].axhspan(.97,1.03,color='tab:green',alpha=.09,label='±3% static screen');ax[1,1].axhline(1,color='gray',ls='--',lw=.8)
ax[1,1].set_xlabel('Final servo PWM (µs)');ax[1,1].set_ylabel('Corrected mean gravity magnitude (g)')
for panel in ax.flat:panel.grid(alpha=.25)
fig.suptitle(folder.name+' — measured settled plateaus, motors stopped\n'+('Basket rotation = negative gravity-vector rotation; initial 1420 µs = 0, physical vertical/yaw sign unassigned' if identified else 'Small arc: hinge plane not identified; XY angles are diagnostic only'))
fig.savefig(folder/'basket-mapping.png',dpi=160);plt.close(fig)
result={'analysis_sha256':hashlib.sha256((folder/'analysis.json').read_bytes()).hexdigest(),'plot_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'identified_plane':identified,'all_settled_windows_pass':report['all_settled_windows_pass'],'angle_convention':'negative gravity-vector rotation around fitted hinge normal' if identified else 'XY gravity diagnostic only','physical_vertical_zero_assigned':False,'angle_span_deg':float(np.nanmax([angle(r) for r in rows])-np.nanmin([angle(r) for r in rows])),'maximum_opposite_approach_angle_difference_deg':max((abs(r[delta_key]) for r in valid),default=None),'measured_adc_range_counts':[min(r['fc']['corrected_pb0_minus_pc0_counts']['mean'] for r in rows),max(r['fc']['corrected_pb0_minus_pc0_counts']['mean'] for r in rows)]}
(folder/'plot-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
