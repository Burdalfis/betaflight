"""Read-only joint mounted baseline; no servo/motor/configuration write calls."""
from pathlib import Path
import sys,json,csv,subprocess,time,signal,hashlib
root=Path('/home/alex/betaflight');sys.path.insert(0,str(root/'tools/tricopter/adxl345_logger'))
import basket_capture as b
p=Path(__file__).resolve().parent;out=p/'mounted-stationary-baseline-02';out.mkdir(exist_ok=False)
fc='/dev/serial/by-id/usb-Betaflight_Betaflight_-_MATEKF405TE_0x8000000-if00';teensy='/dev/serial/by-id/usb-Teensyduino_USB_Serial_12696530-if00';uid='1f003d000551313033383336'
report={'role':'actual mounted read-only stationary baseline','user_sensor_attachment_confirmed':True,'uid':uid,'complete':False,'position_source':'signed PB0-PC0 only','requested_fc_sample_hz':20,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'basket_tool_sha256':hashlib.sha256(Path(b.__file__).read_bytes()).hexdigest()}
m=None;child=None;log=None
try:
 b.verify_usb_identity(fc,teensy,'12696530');m=b.MSP(fc);c=b.Controller(m,expected_uid=uid)
 report['before']=c.backup;report['analog_before_hex']=m.request(110).hex();original=c.original
 log=(out/'adxl-process.log').open('xb')
 child=subprocess.Popen([sys.executable,str(root/'tools/tricopter/adxl345_logger/capture.py'),'--port',teensy,'--output',str(out/'adxl'),'--seconds','15'],stdout=log,stderr=subprocess.STDOUT)
 n=0;fresh_count=0;next_guard=time.monotonic();started=time.monotonic()
 with (out/'fc-readonly-samples.csv').open('x',newline='') as f:
  w=csv.writer(f);w.writerow(['request_host_monotonic_ns','response_host_monotonic_ns','position_fresh','raw_pb0','final_pwm_us','raw_pc0','corrected_pb0_minus_pc0','pair_age_100us','flags','rpm_age_100us','rpm_invalid_stat'])
  while child.poll() is None:
   iteration=time.monotonic()
   if iteration>=next_guard:c.guard();next_guard=time.monotonic()+.1
   before=time.monotonic_ns();v,fresh=b.ground_sample(m.request(b.DEBUG));after=time.monotonic_ns()
   w.writerow([before,after,int(fresh),*v]);n+=1;fresh_count+=fresh
   time.sleep(max(0,.05-(time.monotonic()-iteration)))
 assert child.returncode==0,child.returncode
 report['after']=c.guard();report['analog_after_hex']=m.request(110).hex();report['servo_table_unchanged']=m.request(b.SERVO_CONFIGURATIONS)==original;assert report['servo_table_unchanged']
 report.update(complete=True,fc_samples=n,fc_fresh_samples=fresh_count,fc_fresh_fraction=fresh_count/n,host_duration_s=time.monotonic()-started)
finally:
 if child is not None and child.poll() is None:child.send_signal(signal.SIGINT);child.wait(timeout=5)
 if log:log.close()
 if m:m.close()
 report['files_sha256']={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in out.iterdir() if x.is_file()}
 (out/'readonly-baseline.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['complete','fc_samples','fc_fresh_fraction','servo_table_unchanged']},indent=2))
