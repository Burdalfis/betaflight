"""Identify the authorized Teensy, flash the pinned static FIFO image and record provenance."""
import datetime, hashlib, json, os, pathlib, subprocess, time
import serial.tools.list_ports
root = pathlib.Path("/home/alex/betaflight")
project = root / "tools/tricopter/adxl345_logger"
folder = root / ".local-artifacts/tricopter/adxl345-calibration-2026-11-07/diagnostics"
prefix = folder / "static-fifo-01-flash"
assert not prefix.with_suffix(".json").exists()
ports = [p for p in serial.tools.list_ports.comports() if p.vid == 0x16c0 and p.serial_number == "12696530"]
assert len(ports) == 1, [(p.device, p.vid, p.serial_number) for p in ports]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
paths = [project / n for n in ("src/main.cpp", "include/logger_protocol.h", "platformio.ini")]
source = {str(p.relative_to(root)): sha(p) for p in paths}
hexpath = project / ".pio/build/teensylc_static_fifo/firmware.hex"
hexsha = sha(hexpath)
cmd = ["/home/alex/.platformio/penv/bin/platformio", "run", "-d", str(project), "-e", "teensylc_static_fifo", "-t", "upload"]
env = dict(os.environ, PLATFORMIO_CORE_DIR=str(root / ".local-artifacts/tricopter/adxl345-logger-2026-11-07/platformio"))
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
r = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=40)
prefix.with_suffix(".log").write_bytes(r.stdout)
record = dict(started_utc=started, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), usb_serial="12696530", returncode=r.returncode, command=cmd, hex_sha256=hexsha, hex_unchanged=sha(hexpath)==hexsha, source_sha256=source, sources_unchanged=all(sha(root / n)==v for n,v in source.items()), profile="Static FIFO stream, INT_ENABLE0, SPI pop time only; no actuator or FC access")
prefix.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
assert r.returncode == 0 and record["hex_unchanged"] and record["sources_unchanged"], record
for i in range(50):
    if pathlib.Path("/dev/serial/by-id/usb-Teensyduino_USB_Serial_12696530-if00").exists():
        break
    time.sleep(.1)
else:
    raise RuntimeError("Teensy serial port did not return")
print(json.dumps(record, indent=2))
