"""Preserve measured curves and export their operator-defined flat-basket zero."""
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

base = Path(__file__).resolve().parent
full = base / 'basket-full-sweep-02'
check = base / 'basket-roll-zero-check-01'
spec = importlib.util.spec_from_file_location('zero', base / 'analyze_roll_zero.py')
zero = importlib.util.module_from_spec(spec)
spec.loader.exec_module(zero)
old = json.loads((full / 'measured-angle-tables.json').read_text())
analysis = json.loads((full / 'analysis.json').read_text())
live = json.loads((check / 'roll-zero-result.json').read_text())
normal = old['hinge_normal_sensor_axes']
initial_roll = zero.roll(analysis['plateaus'][0]['adxl']['corrected_mean_g'], normal)
branches = {}
for name, branch in old['branches'].items():
    points = [{**p, 'basket_roll_deg': p['relative_mechanical_rotation_deg'] + initial_roll}
              for p in branch['points']]
    anchor = live['branches'][name]
    counts = [p['corrected_pb0_minus_pc0_counts'] for p in points]
    if not min(counts) <= anchor['interpolated_pb0_minus_pc0_counts'] <= max(counts):
        raise ValueError('Live zero outside measured old branch; extrapolation refused')
    at_zero = float(np.interp(anchor['interpolated_pb0_minus_pc0_counts'], counts,
                              [p['basket_roll_deg'] for p in points]))
    branches[name] = {**branch, 'points': points,
                      'current_zero_check': {**anchor,
                          'original_curve_roll_at_live_zero_count_deg': at_zero,
                          'live_minus_original_curve_deg': -at_zero,
                          'curve_correction_applied': False}}
result = {**old, 'status': 'Offline measured settled angle tables with operator-defined flat-basket roll zero',
          'reference': {'zero_definition': live['zero_definition'],
                        'operator_defined_basket_roll_zero_assigned': True,
                        'original_plateau_id': 0, 'original_command_us': 1420,
                        'original_reference_basket_roll_deg': initial_roll,
                        'external_motor_shaft_vertical_verified': False,
                        'absolute_angle_accuracy_independently_proven': False,
                        'frame_roll_level_operator_report': True,
                        'hinge_parallel_gravity_projected_out': True,
                        'motor_present': False},
          'branches': branches, 'flight_control_calibration_installed': False,
          'transfer_interpretation': 'A common angular reference is applied to the original measured curves. Live brackets check local transfer at zero; curves are not shifted or warped to fit them. No extrapolation beyond each measured count domain.',
          'provenance': {'original_tables_sha256': zero.digest(full / 'measured-angle-tables.json'),
                         'original_analysis_sha256': zero.digest(full / 'analysis.json'),
                         'live_zero_result_sha256': zero.digest(check / 'roll-zero-result.json'),
                         'mounting_reference_sha256': zero.digest(base / 'roll-zero-mounting-reference.json'),
                         'export_script_sha256': zero.digest(__file__)}}
with (full / 'measured-angle-tables-roll-zero.json').open('x') as handle:
    json.dump(result, handle, indent=2, allow_nan=False)
    handle.write('\n')

fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), constrained_layout=True)
colors = {'increasing_pwm': 'tab:blue', 'decreasing_pwm': 'tab:orange'}
for name, branch in branches.items():
    pts = branch['points']
    label = name.replace('_', ' ')
    axes[0].plot([p['corrected_pb0_minus_pc0_counts'] for p in pts], [p['basket_roll_deg'] for p in pts], '.-', lw=1, label=label, color=colors[name])
    near = [p for p in live['points'] if p['approach'] == name.split('_')[0] and 1490 <= p['command_us'] <= 1530]
    near.sort(key=lambda p:p['command_us'])
    axes[1].plot([p['command_us'] for p in near], [p['basket_roll_deg'] for p in near], 'o-', lw=1, color=colors[name], label=label)
    a = live['branches'][name]
    axes[1].plot(a['interpolated_command_us'], 0, marker='x', ms=9, color=colors[name])
    axes[1].annotate(f"{a['interpolated_command_us']:.1f} µs", (a['interpolated_command_us'], 0), xytext=(5, 9 if name=='increasing_pwm' else -18), textcoords='offset points', color=colors[name])
for ax in axes:
    ax.axhline(0, color='gray', lw=.8, ls='--')
    ax.grid(alpha=.25)
    ax.set_ylabel('Basket roll from flat (deg)')
    ax.legend(fontsize=8)
axes[0].set_xlabel('Measured PB0−PC0 (ADC counts)')
axes[0].set_title('Full measured range; common flat-basket reference')
axes[1].set_xlabel('Final commanded PWM (µs)')
axes[1].set_title('Fresh settled check near zero; × = interpolated zero')
fig.suptitle('Operator-aligned PCB X-up reference; motor absent\nHinge-parallel gravity projected out; offline tables only', fontsize=11)
fig.savefig(check / 'basket-roll-zero.png', dpi=160)
plt.close(fig)
print(json.dumps({'original_reference_basket_roll_deg': initial_roll,
                  'live_transfer_residual_deg': {name:b['current_zero_check']['live_minus_original_curve_deg'] for name,b in branches.items()},
                  'exported_tables': str(full / 'measured-angle-tables-roll-zero.json')}, indent=2))
