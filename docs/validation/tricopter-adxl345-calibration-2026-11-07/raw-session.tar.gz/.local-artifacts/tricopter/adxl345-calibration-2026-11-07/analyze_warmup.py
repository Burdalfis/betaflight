"""Analyze fixed-pose time drift; no temperature sensor or cold-start claim."""
import csv,hashlib,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
folder=p/'thermal-xy-mixed-01'
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
summary=json.loads((folder/'summary.json').read_text())
for n,r in summary['files'].items():assert sha(folder/n)==r['sha256']
with (folder/'records.csv').open() as f:rows=list(csv.DictReader(f))
samples=[r for r in rows if r['type']=='sample']
assert all(r['sensor_configured']=='1' and r['fifo_coherent']=='1' and all(r[k]=='0' for k in ['sensor_overrun','service_gap','poll_fallback']) for r in samples)
assert all(len({r[k] for r in rows})==1 for k in ['sensor_overrun_events','service_gap_events','queue_dropped_frames'])
q=summary['quality'];assert q['missing_record_sequences']==q['sequence_discontinuities']==0
assert all(summary['parser'][k]==0 for k in ['crc_errors','discarded_bytes','unsupported_versions','unsupported_types'])
raw=np.array([[int(r['raw_'+k]) for k in 'xyz'] for r in samples],float)
t=np.array([int(r['time_us']) for r in samples],np.int64);assert (np.diff(t)>0).all();t=(t-t[0])/1e6
profile=json.loads((p/'calibration-profile-v1.json').read_text());bias=np.array(profile['bias_counts']);scale=np.array(profile['counts_per_g'])
blocks={}
for width in [1,10]:
 out=[]
 for i in range(int(t[-1]//width)):
  mask=(t>=i*width)&(t<(i+1)*width);m=raw[mask].mean(axis=0);g=(m-bias)/scale
  out.append({'start_s':i*width,'center_s':(i+.5)*width,'samples':int(mask.sum()),'mean_raw_counts':m.tolist(),'corrected_mean_g':g.tolist(),'norm_g':float(np.linalg.norm(g)),'xy_angle_deg':float(np.degrees(np.arctan2(g[1],g[0])))})
 blocks[str(width)]=out
# Complete10-second blocks avoid unequal truncated endpoint windows.
b=blocks['10'];first,last=b[0],b[-1]
first_exact_g=(raw[t<10].mean(axis=0)-bias)/scale
last_exact_g=(raw[t>=t[-1]-10].mean(axis=0)-bias)/scale
exact_angle_change=float(np.degrees(np.arctan2(last_exact_g[1],last_exact_g[0])-np.arctan2(first_exact_g[1],first_exact_g[0])))
result={'samples':len(samples),'read_pop_span_s':float(t[-1]),'first_to_last_exact_10s_xy_angle_change_deg':exact_angle_change,'first_exact_10s_corrected_mean_g':first_exact_g.tolist(),'last_exact_10s_corrected_mean_g':last_exact_g.tolist(),'temperature_measured':False,'cold_start':False,'measurement_contract':'Fixed +X/-Y pose after handling. Firmware samples continuously even while host capture is closed. Only drift versus time and apparent calibrated XY angle are observed; no degrees-C coefficient or cause is established. Actual basket rotation plane still requires mounting data.','profile_sha256':sha(p/'calibration-profile-v1.json'),'input_sha256':{n:sha(folder/n) for n in ['capture.bin','records.csv','summary.json']},'analysis_sha256':sha(__file__),'first_to_last_complete_10s_mean_change_counts':(np.array(last['mean_raw_counts'])-first['mean_raw_counts']).tolist(),'first_to_last_complete_10s_xy_angle_change_deg':last['xy_angle_deg']-first['xy_angle_deg'],'complete_10s_xy_angle_span_deg':float(np.ptp([v['xy_angle_deg'] for v in b])),'complete_1s_xy_angle_span_deg':float(np.ptp([v['xy_angle_deg'] for v in blocks['1']])),'complete_1s_norm_range_g':[min(v['norm_g'] for v in blocks['1']),max(v['norm_g'] for v in blocks['1'])],'complete_10s_norm_range_g':[min(v['norm_g'] for v in b),max(v['norm_g'] for v in b)],'blocks':blocks,'user_reported_thermal_observation':'ADXL chip noticeably warmer than fingers; no temperature instrument available; subjective ~17C rise is not a measured temperature.','interpretation':'Relative fixed-pose XY angle stability is small compared with the practical +/-2deg target. This does not establish absolute angle accuracy, a temperature coefficient or a normal electrical power draw.'}
(folder/'warmup-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
fig,ax=plt.subplots(3,1,figsize=(10,8),sharex=True,constrained_layout=True)
t1=[v['center_s'] for v in blocks['1']];means=np.array([v['mean_raw_counts'] for v in blocks['1']])-first['mean_raw_counts']
for i,k in enumerate('XYZ'):ax[0].plot(t1,means[:,i],label=k,lw=.8)
ax[0].set_ylabel('1s mean change (counts)');ax[0].legend(ncol=3);ax[0].grid(alpha=.25)
ax[1].plot(t1,[v['norm_g'] for v in blocks['1']],lw=.8);ax[1].axhline(1,color='gray',ls='--');ax[1].set_ylabel('Corrected norm (g)');ax[1].grid(alpha=.25)
ax[2].plot(t1,[v['xy_angle_deg']-first['xy_angle_deg'] for v in blocks['1']],color='gray',lw=.6,label='1s means')
ax[2].plot([v['center_s'] for v in b],[v['xy_angle_deg']-first['xy_angle_deg'] for v in b],lw=1.5,label='10s means')
ax[2].scatter([t[-1]-5],[exact_angle_change],s=30,marker='o',facecolors='none',edgecolors='tab:blue',label='Last exact 10s')
ax[2].set_ylabel('Relative XY angle (deg)');ax[2].set_xlabel('Read/pop time from first record (s)');ax[2].grid(alpha=.25);ax[2].legend()
fig.suptitle('Fixed-pose warm-up observation: no measured temperature or power-cycle start\nRaw sources retained; apparent XY angle is not independent absolute-angle truth')
fig.savefig(folder/'warmup-drift.png',dpi=150);plt.close(fig)
print(json.dumps({k:result[k] for k in ['samples','first_to_last_complete_10s_mean_change_counts','first_to_last_complete_10s_xy_angle_change_deg','complete_10s_xy_angle_span_deg','complete_1s_xy_angle_span_deg','complete_1s_norm_range_g']},indent=2))
