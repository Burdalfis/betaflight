"""Analyze an explicit static-FIFO recording; never infer DRDY timing or fit offsets."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def analyze(folder):
    folder = Path(folder)
    summary = json.loads((folder / "summary.json").read_text())
    for name, record in summary["files"].items():
        assert sha(folder / name) == record["sha256"], name
    with (folder / "records.csv").open() as handle:
        rows = list(csv.DictReader(handle))
    samples = [r for r in rows if r["type"] == "sample"]
    statuses = [r for r in rows if r["type"] == "status"]
    assert len(samples) >= 2 and statuses, "Need samples and configuration status"
    axes = np.array([[int(r["raw_" + k]) for k in "xyz"] for r in samples])
    timestamp = np.array([int(r["time_us"]) for r in samples], dtype=np.int64)
    clean = np.array([r["sensor_configured"] == "1" and r["fifo_coherent"] == "1"
        and r["drdy_timestamp_qualified"] == "0"
        and all(r[k] == "0" for k in ("sensor_overrun", "service_gap", "poll_fallback"))
        and 1 <= int(r["fifo_depth_before_read"]) < 32 for r in samples])
    counters = {k: {"first": int(rows[0][k]), "last": int(rows[-1][k]),
        "delta_modulo_uint32": (int(rows[-1][k]) - int(rows[0][k])) & 0xffffffff}
        for k in ("sensor_overrun_events", "service_gap_events", "queue_dropped_frames")}
    registers = sorted({(int(r["devid"]), int(r["bw_rate"]), int(r["data_format"]), int(r["fault_code"]))
        for r in statuses})
    seconds = (timestamp - timestamp[0]) / 1e6
    # Exclude the last partial second for the stability comparison only.
    block_means = np.array([axes[(seconds >= i) & (seconds < i + 1)].mean(axis=0)
        for i in range(int(seconds[-1])) if np.count_nonzero((seconds >= i) & (seconds < i + 1)) >= 100])
    block_span = np.ptp(block_means, axis=0) if len(block_means) >= 2 else np.full(3, np.inf)
    parser = summary["parser"]
    quality = summary["quality"]
    tail_count = parser["truncated_tail_bytes"]
    tail = (folder / "capture.bin").read_bytes()[-tail_count:] if tail_count else b""
    partial_frame_prefix = (not tail or (b"ADXL".startswith(tail) if len(tail) < 4 else tail.startswith(b"ADXL")))
    gates = {
        "all_samples_configured_coherent_clean": bool(clean.all()),
        "healthy_status_registers": registers == [(0xe5, 0x0d, 0x08, 0)],
        "all_statuses_configured": all(r["sensor_configured"] == "1" for r in statuses),
        "sample_pop_times_strictly_increasing": bool((np.diff(timestamp) > 0).all()),
        "no_counter_increments": all(c["delta_modulo_uint32"] == 0 for c in counters.values()),
        "no_intermediate_counter_changes": all(len({int(r[k]) for r in rows}) == 1 for k in counters),
        "no_crc_or_resync_errors": all(parser[k] == 0 for k in ("crc_errors", "unsupported_versions", "unsupported_types", "discarded_bytes")),
        "no_record_sequence_gaps": quality["missing_record_sequences"] == 0 and quality["sequence_discontinuities"] == 0,
        "no_unknown_flags": quality["rows_with_unknown_flag_bits"] == 0,
        "single_uninterrupted_epoch": len(quality["epochs"]) == 1 and quality["usb_session_start_rows"] == 1,
        "tail_is_only_incomplete_frame_prefix": 0 <= tail_count < 64 and partial_frame_prefix,
        "capture_ended_normally": summary["end_reason"] == "input_exhausted",
        "unchanged_capture_sources": summary["source_files_unchanged_during_capture"],
        "at_least_two_complete_seconds": len(block_means) >= 2,
        "axis_std_below_5_counts": bool((axes.std(axis=0) < 5).all()),
        "one_second_mean_span_below_3_counts": bool((block_span < 3).all()),
    }
    result = {
        "input_sha256": {n: sha(folder / n) for n in ("capture.bin", "records.csv", "summary.json")},
        "analysis_sha256": sha(__file__),
        "samples": len(samples), "coherent_clean_samples": int(clean.sum()),
        "mean_raw_counts": axes.mean(axis=0).tolist(), "std_raw_counts": axes.std(axis=0).tolist(),
        "min_raw_counts": axes.min(axis=0).tolist(), "max_raw_counts": axes.max(axis=0).tolist(),
        "one_second_mean_span_counts": block_span.tolist(), "one_second_means_counts": block_means.tolist(),
        "mean_nominal_g": (axes.mean(axis=0) / 256).tolist(),
        "mean_vector_norm_nominal_g": float(np.linalg.norm(axes.mean(axis=0)) / 256),
        "sample_span_read_pop_us": int(timestamp[-1] - timestamp[0]),
        "observed_throughput_hz": float((len(samples) - 1) * 1e6 / (timestamp[-1] - timestamp[0])),
        "fifo_depth_min": min(int(r["fifo_depth_before_read"]) for r in samples),
        "fifo_depth_max": max(int(r["fifo_depth_before_read"]) for r in samples),
        "counter_snapshots": counters, "status_register_tuples_devid_bw_format_fault": registers,
        "gates": gates, "static_capture_gates_pass": all(gates.values()),
        "stationarity_gate_basis": "Conservative session checks: population axis std <5 counts and full one-second mean range <3 counts. These are acceptance heuristics, not sensor specifications or independent proof of no motion.",
        "measurement_contract": "Raw uncalibrated coherent FIFO vectors. time_us is SPI read/pop start, with unmeasured sample age; throughput is not precise per-sample timing. No offsets/scales/angles fitted. Do not use for millisecond movement timing.",
        "parser": parser, "quality": quality,
    }
    (folder / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
    fig, panels = plt.subplots(4, 1, figsize=(10, 8), sharex=True, constrained_layout=True)
    for i, k in enumerate("XYZ"):
        panels[i].plot(seconds, axes[:, i], lw=.4)
        panels[i].set_ylabel(k + " counts")
        panels[i].grid(alpha=.25)
    panels[3].plot(seconds, [int(r["fifo_depth_before_read"]) for r in samples], lw=.5)
    panels[3].set_ylabel("FIFO entries")
    panels[3].set_xlabel("SPI read/pop time from first record (s); sensor sample age unmeasured")
    panels[3].grid(alpha=.25)
    fig.suptitle(f"{folder.name}: {len(samples):,} raw stationary FIFO vectors; no calibration fit")
    fig.savefig(folder / "stationary.png", dpi=150)
    plt.close(fig)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    result = analyze(parser.parse_args().folder)
    print(json.dumps({k: result[k] for k in ("samples", "mean_raw_counts", "std_raw_counts", "fifo_depth_max", "static_capture_gates_pass", "gates")}, indent=2))
