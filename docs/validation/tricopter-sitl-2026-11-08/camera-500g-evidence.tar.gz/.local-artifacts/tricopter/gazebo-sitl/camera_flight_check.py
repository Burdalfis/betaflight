import sys, os, time, math, json, threading, subprocess
from pathlib import Path
sys.path.insert(0, str(Path('/home/alex/betaflight/tools/tricopter/sitl')))
import check_flight as flight
from run import frame_viewer, native_environment
from runtime import ARTIFACTS, HERE, SessionLock, fresh_run_directory
from gz.transport import Node
from gz.msgs.pose_pb2 import Pose
from gz.msgs.pose_v_pb2 import Pose_V
from gz.msgs.cameratrack_pb2 import CameraTrack
from gz.msgs.stringmsg_pb2 import StringMsg
from gz.msgs.boolean_pb2 import Boolean

variant = sys.argv[1] if len(sys.argv) > 1 else 'stock'
os.environ['GZ_PARTITION'] = f'tricopter-flight-{os.getpid()}-{variant}'
directory = fresh_run_directory(ARTIFACTS, variant, 'camera-flight')
samples, statuses, poses = [], [], {}
actual_commands=[]
node = Node()
def plain(p):
    return {'p':[p.position.x,p.position.y,p.position.z],
            'q':[p.orientation.w,p.orientation.x,p.orientation.y,p.orientation.z]}
def world(msg):
    for p in msg.pose: poses[p.name] = plain(p)
def camera(msg):
    samples.append({'wall':time.monotonic(),'camera':plain(msg),
                    'proxy':poses.get('tricopter_camera_heading'), 'craft':poses.get('tricopter')})
def status(msg):
    statuses.append({'mode':msg.track_mode,'follow':msg.follow_target.name,'track':msg.track_target.name})
node.subscribe(Pose_V, '/world/tricopter/pose/info', world)
node.subscribe(Pose, '/gui/camera/pose', camera)
node.subscribe(CameraTrack, '/gui/currently_tracked', status)
real_start, real_wait = flight.start_child, flight.wait_for_plant
def start(command, **kw):
    if command[:2] == ['gz','sim']:
        command = [v for v in command if v != '-s']
        command[2:2] = ['--render-engine-gui','ogre']
        env = native_environment(); env.update(kw.get('env',{}))
        env['QT_QPA_PLATFORM']='xcb';env.pop('WAYLAND_DISPLAY',None)
        kw['env'] = env
        actual_commands.append(command.copy())
    return real_start(command, **kw)
def wait(path, firmware, gazebo, client, which, **kw):
    real_wait(path, firmware, gazebo, client, which, **kw)
    env = native_environment();env['GZ_PARTITION']=os.environ['GZ_PARTITION']
    frame_viewer(env,path)
    def screenshot():
        time.sleep(9)
        dest=(path/'screenshots').resolve();dest.mkdir(exist_ok=True)
        # Keep synchronous Gazebo Python transport requests out of this process:
        # its binding holds the GIL while waiting, stalling the RC send thread.
        subprocess.run(['gz','service','-s','/gui/screenshot','--reqtype','gz.msgs.StringMsg',
            '--reptype','gz.msgs.Boolean','--timeout','2000','--req','data:'+json.dumps(str(dest))],
            env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=4)
    threading.Thread(target=screenshot,daemon=True).start()
flight.start_child,flight.wait_for_plant = start,wait
def euler(q):
    w,x,y,z=q
    return [math.atan2(2*(w*x+y*z),1-2*(x*x+y*y)),
            math.asin(max(-1,min(1,2*(w*y-z*x)))),
            math.atan2(2*(w*z+x*y),1-2*(y*y+z*z))]
report={'pass':False}
try:
    with SessionLock():
        plugin=ARTIFACTS/'gazebo-build/libTricopterBridge.so'
        print(f'GUI flight evidence: {directory}',flush=True)
        report['flight']=flight.run_variant(ARTIFACTS,variant,plugin,HERE/'gazebo/worlds/tricopter.sdf',directory/variant)
        report['flight']['command']=actual_commands[-1]
        (directory/variant/'flight-check.json').write_text(json.dumps(report['flight'],indent=2)+'\n')
    selected=[s for s in samples if s['proxy'] and s['craft']]
    report['pose_names']=list(poses);report['camera_samples']=len(selected)
    # Skip the initial move-to animation; both tracking targets must resolve.
    tracked=[s for s in statuses if s['mode']==4 and s['follow']=='tricopter_camera_heading' and s['track']=='tricopter']
    report['resolved_tracking_samples']=len(tracked)
    selected=[s for s in selected if s['wall']>selected[0]['wall']+2] if selected else []
    offsets=[];proxy_tilt=[];camera_roll=[];heights=[];yaws=[]
    for s in selected:
        proxy,cam=s['proxy'],s['camera']; yaw=euler(proxy['q'])[2]
        d=[a-b for a,b in zip(cam['p'],proxy['p'])]
        local=[math.cos(yaw)*d[0]+math.sin(yaw)*d[1],-math.sin(yaw)*d[0]+math.cos(yaw)*d[1],d[2]]
        offsets.append(math.sqrt(sum((a-b)**2 for a,b in zip(local,[-2.4,0,1]))))
        proxy_tilt.append(max(abs(v) for v in euler(proxy['q'])[:2])*180/math.pi)
        camera_roll.append(abs(euler(cam['q'])[0])*180/math.pi)
        heights.append(cam['p'][2]);yaws.append(euler(cam['q'])[2]*180/math.pi)
    report.update(camera_offset_max_error_m=max(offsets) if offsets else None,
                  camera_offset_rms_error_m=math.sqrt(sum(v*v for v in offsets)/len(offsets)) if offsets else None,
                  proxy_max_roll_pitch_deg=max(proxy_tilt) if proxy_tilt else None,
                  camera_max_roll_deg=max(camera_roll) if camera_roll else None,
                  camera_height_range_m=[min(heights),max(heights)] if heights else None,
                  camera_yaw_range_deg=[min(yaws),max(yaws)] if yaws else None)
    assert tracked and len(selected)>30, report
    assert max(proxy_tilt)<.001 and max(camera_roll)<.1, report
    assert report['camera_offset_rms_error_m']<.08 and max(offsets)<.3, report
    assert max(heights)-min(heights)>.8 and max(yaws)-min(yaws)>8, report
    report['pass']=True
finally:
    (directory/'camera-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
    (directory/'camera-status.json').write_text(json.dumps(statuses,indent=2)+'\n')
    (directory/'camera-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='flight'},indent=2),flush=True)
