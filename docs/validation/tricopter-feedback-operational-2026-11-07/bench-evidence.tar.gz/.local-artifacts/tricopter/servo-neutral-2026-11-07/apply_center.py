"""Apply only servo5 middle=1509, persist and verify after normal reboot."""
import json
from pathlib import Path
import sys
import time

import serial

sys.path.insert(0, str(Path('tools/tricopter/adxl345_logger').resolve()))
from basket_capture import MSP, Controller, SERVO_RECORD, SET_SERVO_CONFIGURATION, SERVO_CONFIGURATIONS, BOXIDS, ground_sample, DEBUG, write_json

ROOT = Path(__file__).resolve().parent
PORT = '/dev/serial/by-id/usb-Betaflight_Betaflight_-_MATEKF405TE_0x8000000-if00'
UID = '1f003d000551313033383336'
INDEX, NEW_CENTER = 5, 1509
STEPS = [1440, 1460, 1480, 1500, NEW_CENTER]


def fresh_guard(controller):
    state = controller.guard()
    deadline = time.monotonic() + .1
    while not state['position_fresh']:
        if time.monotonic() >= deadline:
            raise RuntimeError('Fresh PB0-PC0 missing for100ms')
        time.sleep(.005)
        raw = controller.msp.request(DEBUG)
        values, fresh = ground_sample(raw)
        state.update(debug_values=list(values), position_fresh=fresh)
    return state


m = MSP(PORT)
report = {'servo_index': INDEX, 'new_middle_us': NEW_CENTER,
          'tested_pwm_limits_us': [1100,1700], 'firmware_flash_performed':False,
          'steps':[], 'EEPROM_save_attempted':False, 'persisted_after_reboot':False}
c = None
expected = None
try:
    c = Controller(m, expected_uid=UID, servo_index=INDEX)
    original = (ROOT / 'original-servo-table.bin').read_bytes()
    if c.original != original or c.fields != (1100,1700,1420,100,255,0):
        raise RuntimeError('Configuration differs from backed-up original')
    expected = original
    for target in STEPS:
        fresh_guard(c)
        if m.request(SERVO_CONFIGURATIONS) != expected:
            raise RuntimeError('Servo table changed outside this operation')
        record = SERVO_RECORD.pack(c.fields[0],c.fields[1],target,*c.fields[3:])
        planned = bytearray(original)
        planned[INDEX*12:(INDEX+1)*12] = record
        # Record both possible outcomes before writing: a missing ACK can still
        # follow a successful write, so rollback recognizes either exact table.
        report['allowed_current_tables'] = [expected.hex(),bytes(planned).hex()]
        m.request(SET_SERVO_CONFIGURATION,bytes([INDEX])+record)
        if m.request(SERVO_CONFIGURATIONS) != bytes(planned):
            raise RuntimeError('Exact servo-table readback failed')
        expected = bytes(planned)
        time.sleep(.30)
        state = fresh_guard(c)
        if state['debug_values'][1] != target:
            raise RuntimeError('Final PWM does not equal new middle')
        report['steps'].append({'target_us':target,'state':state})
    report['expected_servo_table_hex'] = expected.hex()
    report['changed_byte_offsets'] = [i for i,(a,b) in enumerate(zip(original,expected)) if a!=b]
    if report['changed_byte_offsets'] != [64]:
        raise RuntimeError('Unexpected bytes changed beyond servo5 middle')
    fresh_guard(c)
    report['EEPROM_save_attempted'] = True
    m.request(250,timeout=3)
    report['EEPROM_save_acknowledged'] = True
    time.sleep(.30)
    fresh_guard(c)
    if m.request(SERVO_CONFIGURATIONS) != expected:
        raise RuntimeError('Table differs after EEPROM reload')
    report['normal_reboot_ack_hex'] = m.request(68,b'\x00',timeout=2).hex()
    m.close(); m = None
    deadline = time.monotonic()+15
    while time.monotonic() < deadline:
        try:
            candidate = MSP(PORT)
        except (serial.SerialException,OSError):
            time.sleep(.2); continue
        try:
            c.msp=candidate
            state=fresh_guard(c)
            if candidate.request(BOXIDS).hex()!=c.backup['boxids_hex']:
                raise RuntimeError('Mode-ID layout changed after reboot')
            if candidate.request(SERVO_CONFIGURATIONS)!=expected:
                raise RuntimeError('Persisted servo table differs after reboot')
            if state['debug_values'][1]!=NEW_CENTER:
                raise RuntimeError('Post-reboot finalPWM is not1509')
            m=candidate
            break
        except Exception:
            candidate.close()
            raise
    else:
        raise RuntimeError('FC did not reconnect within15seconds')
    report.update(persisted_after_reboot=True,post_reboot_state=state,
                  final_servo_fields=list(SERVO_RECORD.unpack_from(expected,INDEX*12)),
                  identity=c.identity)
except BaseException as error:
    report['error']=f'{type(error).__name__}: {error}'
    # Only an unsaved operation is automatically rolled back. After a save
    # attempt, retain exact evidence and inspect persistence instead of guessing.
    if c is not None and m is not None and not report['EEPROM_save_attempted']:
        try:
            c.msp=m; c.guard(require_ground=False)
            current=m.request(SERVO_CONFIGURATIONS)
            if current.hex() not in report.get('allowed_current_tables',[c.original.hex()]):
                raise RuntimeError('Unexpected external table prevents rollback')
            m.request(SET_SERVO_CONFIGURATION,bytes([INDEX])+c.original_record)
            report['unsaved_rollback_exact']=m.request(SERVO_CONFIGURATIONS)==c.original
        except Exception as rollback:
            report['rollback_error']=f'{type(rollback).__name__}: {rollback}'
    raise
finally:
    if m is not None:m.close()
    write_json(ROOT/'apply-result.json',report)

print(json.dumps({'persisted_after_reboot':report['persisted_after_reboot'],
                  'final_servo_fields':report['final_servo_fields'],
                  'motors':state['motor_outputs'][:3], 'final_pwm_us':state['debug_values'][1],
                  'fresh_pb0_minus_pc0':state['position_fresh']}))
