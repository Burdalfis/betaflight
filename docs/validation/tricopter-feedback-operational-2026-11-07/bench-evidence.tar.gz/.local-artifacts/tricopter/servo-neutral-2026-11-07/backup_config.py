import json
from pathlib import Path
import sys
import time

import serial

sys.path.insert(0, str(Path('tools/tricopter/adxl345_logger').resolve()))
from basket_capture import MSP, Controller, write_json

PORT = '/dev/serial/by-id/usb-Betaflight_Betaflight_-_MATEKF405TE_0x8000000-if00'
UID = '1f003d000551313033383336'
ROOT = Path(__file__).resolve().parent


def read_prompt(connection, timeout=20):
    data = bytearray()
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        data.extend(connection.read(max(1, connection.in_waiting)))
        if data.endswith(b'# '):
            return bytes(data)
    raise TimeoutError(f'No CLI prompt after {len(data)} bytes')


def snapshot(name):
    connection = serial.Serial(PORT, 115200, timeout=.03, exclusive=True)
    replies = {}
    try:
        connection.write(b'#'); connection.flush()
        replies['enter'] = read_prompt(connection)
        for command in ['version', 'status', 'dump all', 'diff all', 'resource show all', 'servo', 'get servo_center_pulse', 'get tri_unarmed_servo']:
            connection.write(command.encode() + b'\r'); connection.flush()
            response = read_prompt(connection)
            if any(value in response for value in [b'###ERROR', b'Unknown command', b'Invalid name', b'Parse error']):
                raise RuntimeError(f'CLI rejected {command}')
            replies[command] = response
    finally:
        connection.write(b'exit noreboot\r'); connection.flush()
        time.sleep(.15)
        connection.close()
    with (ROOT / (name + '-cli.txt')).open('xb') as handle:
        for response in replies.values():
            handle.write(response)
    for command in ['dump all', 'diff all']:
        with (ROOT / (name + '-' + command.replace(' ', '-') + '.txt')).open('xb') as handle:
            handle.write(replies[command])
    return {command: len(value) for command, value in replies.items()}


if __name__ == '__main__':
    name = sys.argv[1]
    if name == 'before':
        m = MSP(PORT)
        try:
            c = Controller(m, expected_uid=UID)
            if c.backup['debug_values'][1] != 1420:
                raise RuntimeError('Expected original1420 neutral before trim')
            write_json(ROOT / 'before-msp.json', c.backup)
            (ROOT / 'original-servo-table.bin').write_bytes(c.original)
        finally:
            m.close()
    print(json.dumps(snapshot(name)))
