"""Local bench CLI transport; confirm identity/disarmed motors before entry."""
from pathlib import Path
import sys
import time
import struct
import serial

sys.path.insert(0, str(Path('tools/tricopter/adxl345_logger').resolve()))
from basket_capture import MSP

PORT='/dev/serial/by-id/usb-Betaflight_Betaflight_-_MATEKF405TE_0x8000000-if00'


def prompt(connection,timeout=20):
    data=bytearray();deadline=time.monotonic()+timeout;last=time.monotonic()
    while time.monotonic()<deadline:
        chunk=connection.read(max(1,connection.in_waiting))
        if chunk:data.extend(chunk);last=time.monotonic()
        if data.endswith(b'# ') and time.monotonic()-last>=.1:return bytes(data)
    raise TimeoutError('CLI prompt did not settle')


class CLI:
    def __init__(self,path):
        m=MSP(PORT)
        try:
            assert m.request(160).hex()=='1f003d000551313033383336'
            boxes=m.request(119);status=m.request(150)
            assert not(struct.unpack_from('<I',status,6)[0]&(1<<boxes.index(0)))
            assert struct.unpack('<8H',m.request(104))[:3]==(1000,1000,1000)
        finally:m.close()
        self.log=Path(path).open('xb')
        self.serial=serial.Serial(PORT,115200,timeout=.03,exclusive=True)
        self.serial.write(b'#');self.serial.flush();self.log.write(prompt(self.serial));self.log.flush()

    def request(self,command):
        self.serial.write(command.encode()+b'\r');self.serial.flush()
        data=prompt(self.serial);self.log.write(data);self.log.flush()
        if any(s in data for s in [b'###ERROR',b'Unknown command',b'Invalid name',b'Parse error']):raise RuntimeError(data.decode(errors='replace'))
        return data.decode(errors='replace')

    def close(self):
        self.serial.write(b'exit noreboot\r');self.serial.flush();time.sleep(.15)
        self.serial.close();self.log.close()
