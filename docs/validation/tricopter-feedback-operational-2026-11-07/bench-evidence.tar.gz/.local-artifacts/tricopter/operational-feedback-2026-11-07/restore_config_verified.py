from pathlib import Path
import sys,json,time
p=Path(__file__).resolve().parent;sys.path.insert(0,str(p))
from cli_io import CLI,PORT
lines=(p/'preflash-complete-diff-all.txt').read_text().splitlines()
commands=[s.strip() for s in lines if s.strip() and not s.lstrip().startswith('#') and s.strip() not in ('diff all','save')]
assert commands[0]=='batch start' and commands[1]=='defaults nosave'
c=CLI(p/'configuration-restore-verified-cli.txt')
try:
    for i,cmd in enumerate(commands):
        c.request(cmd)
        if (i+1)%100==0:print(f'Restored diff {i+1}/{len(commands)}',flush=True)
    print(c.request('batch end'),flush=True)
    print(c.request('mixer'),flush=True)
    print(c.request('save noreboot'),flush=True)
    print(c.request('mixer'),flush=True)
    print(c.request('servo'),flush=True)
finally:c.close()
sys.path.insert(0,str(Path('tools/tricopter/adxl345_logger').resolve()))
from basket_capture import MSP
m=MSP(PORT)
try:
    try:m.request(68,b'\x00',timeout=1)
    except Exception as e:print('Requested reboot:',type(e).__name__,flush=True)
finally:m.close()
(p/'configuration-restore-verified.json').write_text(json.dumps({'commands_restored':len(commands),'all_cli_commands_accepted':True,'save_noreboot_acknowledged':True,'msp_reboot_sent':True},indent=2)+'\n')
