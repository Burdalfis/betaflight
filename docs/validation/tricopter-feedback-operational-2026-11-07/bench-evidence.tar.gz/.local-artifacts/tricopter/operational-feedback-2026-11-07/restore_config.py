from pathlib import Path
import sys,json,time
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p))
from cli_io import CLI
lines=(p/'preflash-complete-dump-all.txt').read_text().splitlines()
commands=[s.strip() for s in lines if s.strip() and not s.lstrip().startswith('#') and s.strip() not in ('dump all','save')]
assert commands[0]=='batch start'
assert 'mixer TRI' in commands and 'servo 5 1100 1700 1509 100 -1' in commands
c=CLI(p/'configuration-restore-cli.txt')
try:
    for i,cmd in enumerate(commands):
        c.request(cmd)
        if (i+1)%100==0: print(f'Restored {i+1}/{len(commands)} commands',flush=True)
    for cmd in ['get tri','servo','diff all']:
        data=c.request(cmd)
        (p/('restored-presave-'+cmd.replace(' ','-')+'.txt')).write_text(data)
    c.serial.write(b'save\r');c.serial.flush()
    deadline=time.monotonic()+2
    while time.monotonic()<deadline:
        try:
            chunk=c.serial.read(4096)
            if chunk:c.log.write(chunk);c.log.flush()
        except Exception:break
    (p/'configuration-restore.json').write_text(json.dumps({'commands_restored':len(commands),'all_cli_commands_accepted':True,'save_sent':True},indent=2)+'\n')
    print('Complete backup restored and save sent',flush=True)
finally:
    c.serial.close();c.log.close()
