from pathlib import Path
import sys,time,json,re,struct
p=Path(__file__).resolve().parent
sys.path.insert(0,str(p))
from cli_io import CLI,PORT
sys.path.insert(0,str(Path('tools/tricopter/adxl345_logger').resolve()))
from basket_capture import MSP

def wait():
    deadline=time.monotonic()+12
    time.sleep(1)
    while time.monotonic()<deadline:
        if Path(PORT).exists():
            try:
                m=MSP(PORT); ident=m.request(160);m.close()
                if ident.hex()=='1f003d000551313033383336':return
            except Exception:pass
        time.sleep(.25)
    raise RuntimeError('FC reconnect timeout')

def save(c):
    acknowledgement=c.request('save noreboot')
    assert '# saving' in acknowledgement
    c.close()
    m=MSP(PORT)
    try:
        try:m.request(68,b'\x00',timeout=1)
        except Exception:pass
    finally:m.close()
    wait()

def snapshot(name):
    c=CLI(p/(name+'-cli.txt'))
    try:
        result={}
        for cmd in ['version','status','servo','dump all','diff all','tricopter_calibrate status']:
            data=c.request(cmd);result[cmd]=data
            (p/(name+'-'+cmd.replace(' ','-')+'.txt')).write_text(data)
        print(result['status'],flush=True);print(result['tricopter_calibrate status'],flush=True)
        return result
    finally:c.close()

def command_lines(data):
    return [s.strip() for s in data.splitlines() if s.strip() and not s.lstrip().startswith('#') and s.strip() not in ('dump all','diff all')]

def compare(data):
    before=command_lines((p/'preflash-complete-dump-all.txt').read_text())
    after=command_lines(data)
    new=[s for s in after if re.match(r'set tri_(angle_|adc_|yaw_gain|servo_p|feedback_timeout|yaw_trim|yaw_direction|servo_speed)',s)]
    remaining=[s for s in after if s not in new]
    assert remaining==before,'Existing configuration differs: inspect dumps'
    return {'existing_commands_unchanged':len(before),'new_commands':new}

wait()
result=snapshot('restored-reboot-verified')
comparison=compare(result['dump all'])
(p/'configuration-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
assert 'config=1 feedback=1 vector=1' in result['tricopter_calibrate status']
assert 'TRI_FEEDBACK' not in result['status']
print('All existing configuration commands preserved after reboot',flush=True)
c=CLI(p/'debug-none-save-cli.txt')
c.request('set debug_mode = NONE');save(c)
result=snapshot('debug-none-reboot')
assert 'config=1 feedback=1 vector=1' in result['tricopter_calibrate status']
assert 'set debug_mode = NONE' in result['dump all']
print('Feedback valid with debug NONE after reboot',flush=True)

c=CLI(p/'disarmed-motion-and-calibration-cli.txt')
records=[]
def status(label):
    text=c.request('tricopter_calibrate status')
    fields={k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',text)}
    fields['label']=label;fields['host_monotonic']=time.monotonic()
    records.append(fields)
    assert fields.get('config')==1 and fields.get('feedback')==1 and fields.get('vector')==1,text
    assert 1100<=fields['pwm']<=1700,text
    return fields
try:
    c.request('set tri_yaw_trim = 0');time.sleep(.5);status('center-initial')
    for trim in [50,-50,0]:
        c.request(f'set tri_yaw_trim = {trim}');time.sleep(.7)
        for _ in range(5):status(f'trim-{trim}');time.sleep(.05)
    c.request('tricopter_calibrate start')
    deadline=time.monotonic()+9
    while time.monotonic()<deadline:
        f=status('calibration-running')
        if f.get('complete')==1:break
        assert f.get('status') not in [3,4,5,6,7,8,9],f
        time.sleep(.15)
    assert f.get('complete')==1 and f.get('result')==1,f
    time.sleep(.3);hold=status('calibration-completed-hold')
    assert hold['pwm']==1509 and hold.get('complete')==1
    c.request('tricopter_calibrate apply');time.sleep(.5);status('calibration-applied-ram')
    for key,value in [('tri_adc_low',1936),('tri_adc_mid',1490),('tri_adc_high',1281),('tri_servo_speed',0)]:c.request(f'set {key} = {value}')
    c.request('tricopter_calibrate start');time.sleep(.2)
    c.request('tricopter_calibrate abort');time.sleep(.5);status('calibration-aborted-centered')
    print('Disarmed trim and optional calibration checks completed',flush=True)
finally:
    c.request('tricopter_calibrate abort');c.request('set tri_yaw_trim = 0')
    for key,value in [('tri_adc_low',1936),('tri_adc_mid',1490),('tri_adc_high',1281),('tri_servo_speed',0)]:c.request(f'set {key} = {value}')
    time.sleep(.4)
    c.request('set debug_mode = TRI_GROUND')
    save(c)
    (p/'disarmed-motion-records.json').write_text(json.dumps(records,indent=2)+'\n')
final=snapshot('final')
assert compare(final['dump all'])==comparison
assert 'config=1 feedback=1 vector=1' in final['tricopter_calibrate status']
m=MSP(PORT)
try:
    servo=m.request(120)
    assert servo==(p/'original-servo-table.bin').read_bytes()
    boxes=m.request(119);status_data=m.request(150)
    assert not(struct.unpack_from('<I',status_data,6)[0]&(1<<boxes.index(0)))
    motors=struct.unpack('<8H',m.request(104));assert motors[:3]==(1000,1000,1000)
    (p/'final-msp.json').write_text(json.dumps({'uid_hex':m.request(160).hex(),'motors':motors,'servo_table_preserved':True,'armed':False},indent=2)+'\n')
finally:m.close()
print('Final saved settings match pre-flash config plus default new TRI fields; motors stopped',flush=True)
